import Navbar3 from './components/Navbar3'
import { WavyBackground } from './components/ui/WavyBackground'
import { FeaturesSectionDemo } from './components/ui/FeaturesSectionDemo'
import bgImage from "/images/hero/bg.jpeg"
import { BackgroundGradient } from './components/ui/BackgroundGradient'
import AboutData from './components/ui/AboutData'
import HowWeWork from './components/ui/HowWeWork'
import { AnimatedTestimonials } from './components/ui/AnimatedTestimonials'
import { testimonials } from './components/ui/testimonials'
import { HoverEffect } from './components/ui/HoverEffect'
import { items } from './components/ui/items'
import ContactUs from './components/ui/ContactUs'
import Footer from './components/ui/Footer'
import './App.css'




function App() {

  return (
    <>
    <div className='overflow-auto'>
     <Navbar3/>
     <WavyBackground className="heading text-black  text-7xl font-extrabold ml-28" blur={0} backgroundImage={bgImage} desc="Delivering Quality Software Products and Premium IT Services Since 2013">
      BigByteWorld
     </WavyBackground>
      <FeaturesSectionDemo/>
      <div className='flex justify-center items-center  mt-10 mb-10 rounded-2xl  p-20 w-[100vw]'>
      <BackgroundGradient animate={true} containerClassName="rounded-3xl shadow-xl w-80% max-w-full"
        className="bg-white text-black p-6 rounded-3xl ">
       <AboutData/>
      </BackgroundGradient>
      </div>
      <HowWeWork/>
      <HoverEffect items={items} className=""/>
      <ContactUs/>
      <AnimatedTestimonials testimonials={testimonials} autoplay={true}/>
      <Footer/>
      
     </div>
    </>
  );
}

export default App;
