export const testimonials =[
    {
        quote:"Best digital marketing company in kurukshetra (Haryana)",
      name: "Puneet Sharma",
      designation: "Manager at BigByte ",
      src:  "/images/test/te1.jpg",
    },
    {
        quote: "The best company for digital marketing and web designing in Kurukshetra.",
      name: "muskan sethi",
      designation: "Intern",
      src: "/images/test/te2.jpg",
    },{
        quote:
        "Great environment and supportive staff as well as best company for web development and digital marketing",
      name: "VISHAL Kumar",
      designation: "Intern",
      src: "/images/test/te3.jpg",
    },
    {
        quote:
        "One of the best multi tasking company in kurukshetra. And best trainers in this company.",
      name: "Dipakshi Sharma",
      designation: "Intern",
      src: "/images/test/te4.jpg",
    },
    {
        quote:
        "Work enviorment is soo good.Very informative, competitive, good work culture, seniors are very good and supportive,",
      name: "Amit",
      designation: "Intern",
      src: "/images/test/te1.jpg",
    },
    {
        quote:
        "One of the best it company in Kurukshetra. Would recommend for website development and social media",
      name: "Aditya Sharma",
      designation: "Intern",
      src: "/images/test/te5.jpg",
    },
]